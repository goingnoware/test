package com.epusn.clickevent;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Scroller;

import com.epusn.clickevent.util.AniUtils;

import java.util.ArrayList;

public class JobActivity extends AppCompatActivity {
    View view;

    ListView list_view;
    Scroller mScro;
    private Button button;
    private ArrayAdapter<String> adapter = null;
    private ArrayList<String> items = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);



        list_view = (ListView) findViewById(R.id.list_view);

        // 测试数据集。
        mScro = new Scroller(this);
        items = new ArrayList<String>();
        for (int i = 0; i < 15; i++) {
            items.add("数据:" + i);
        }

        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, items);
        list_view.setAdapter(adapter);
        AniUtils.translationX(list_view);

    }

}

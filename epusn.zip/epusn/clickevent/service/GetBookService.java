package com.epusn.clickevent.service;

import retrofit2.http.GET;
import retrofit2.http.Query;
import rx.Observable;

/**
 * Created by doit on 2018/3/7 0007.
 */

 public  interface  GetBookService {

    @GET("book/search")
    Observable<Book> getSearchBook(@Query("q") String name,
                                     @Query("tag") String tag,
                                     @Query("start") int start,
                                     @Query("count") int count);




}



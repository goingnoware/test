package com.epusn.clickevent.util;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;

/**
 * Created by doit on 2018/3/25 0025.
 */

public class AniUtils {
    public static void translationX(final View view) {


        ObjectAnimator animator = ObjectAnimator.ofFloat(view, "translationY", -1600);
        animator.setDuration(300);//动画时间
        animator.setInterpolator(new AccelerateInterpolator());//动画插值
//        animator.setRepeatCount(-1);//设置动画重复次数
//        animator.setRepeatMode(ValueAnimator.RESTART);//动画重复模式
//        animator.setStartDelay(1000);//动画延时执行
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                Log.e("fenshu", animation.getAnimatedFraction() * 400
                        + "");
                view.layout(view.getLeft(), view.getTop(), view.getRight(), view.getBottom() + (int) animation.getAnimatedFraction() * 1600);
            }
        });
        animator.start();//启动动画
    }
}

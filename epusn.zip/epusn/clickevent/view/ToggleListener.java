package com.epusn.clickevent.view;

public interface ToggleListener {
    void onToggled(boolean isOpen);
}

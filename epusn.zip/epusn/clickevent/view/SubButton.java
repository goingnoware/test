package com.epusn.clickevent.view;

import android.content.Context;
import android.util.AttributeSet;

/**
 * Created by doit on 2018/3/10 0010.
 */

public class SubButton extends android.support.v7.widget.AppCompatButton {
    public SubButton(Context context) {
        super(context);
    }

    public SubButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SubButton(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void computeScroll() {
        super.computeScroll();
    }
}

package com.epusn.clickevent;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Scroller;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView list_view;
    Scroller mScro;
    private Button button;
    private ArrayAdapter<String> adapter = null;
    private ArrayList<String> items = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list_view = (ListView) findViewById(R.id.list_view);
        button = (Button) findViewById(R.id.button);
        // 测试数据集。
        mScro = new Scroller(this);
        items = new ArrayList<String>();
        for (int i = 0; i < 5; i++) {
            items.add("数据:" + i);
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mScro.startScroll(40, 40, 40, 40);
                list_view.scrollBy(30, 30);
                startActivity(new Intent(MainActivity.this, BActivity.class));
            }
        });
        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, items);
        list_view.setAdapter(adapter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, JobActivity.class));
            }
        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("hehe", "onResume");
    }

    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
        Log.e("hehe", "onSaveInstanceState");

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("hehe", "onStart");
    }

    private void niubi(int i, double mm) {
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("hehe", "onStop");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("hehe", "onPause");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("hehe", "onDestroy");
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.e("hehe", "onConfigurationChanged");
    }
}

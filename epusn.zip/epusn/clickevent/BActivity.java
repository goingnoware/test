package com.epusn.clickevent;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class BActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);
        Log.e("hehe","b  oncreat");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e("hehe","b onresume");

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("hehe","b  onstart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("hehe","  b   onpause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("hehe","b  on stop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e("hehe","  b   ondestory");
    }
}
